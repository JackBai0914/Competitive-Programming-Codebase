g++ data.cpp -o data -O2
g++ 1.cpp -o 1 -O2
g++ 1.1.cpp -o 1.1 -O2

./data
./1
./1.1