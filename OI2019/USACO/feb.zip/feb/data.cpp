#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
using namespace std;
typedef long double ld;
const ld eps = 1e-9;
int output(ld x) {return (int)((x + eps) * 1000000);}
int n;
ld p[1000010], fans = 0;

ld Rand() {return (ld)rand() / RAND_MAX;}


int main() {
	srand(time(0));
	freopen("cowdate.in", "w", stdout);
	const int n = 2000;
	cout << n << endl;
	for (int i = 1; i <= n; i ++)
		cout << output(Rand()) << " "; 
	return 0;
}


